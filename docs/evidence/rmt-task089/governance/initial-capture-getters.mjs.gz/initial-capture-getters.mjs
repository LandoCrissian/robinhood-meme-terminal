import assert from "node:assert/strict";
import {createRequire} from "node:module";
import {readFileSync,writeFileSync} from "node:fs";
import {createHash} from "node:crypto";
import {execFileSync} from "node:child_process";
import {setTimeout as delay} from "node:timers/promises";
const repository="/workspace/home/robinhood-meme-terminal";
const require=createRequire(repository+"/apps/launch-website/package.json");
const {parseAbi,encodeFunctionData,decodeFunctionResult,decodeEventLog,keccak256}=require("viem");
const urls={official:"https://rpc.mainnet.chain.robinhood.com",pocket:"https://robinhood.api.pocket.network"};
const directory="0xE677A69A8124714DD0d88b73BDf1B89cc791ca9C";
const factory="0x7281e1F9D8764Ae6533b374DFd08AB2ECbC273c3";
const scheduleHash="0x96bd234e49d766c73c66f9787f26736040b4fc64d91ed2ae888eca3f4c8afb65";
const scheduled=JSON.parse(readFileSync(repository+"/docs/evidence/mobile-signing/factory-publication-scheduled.json"));
const digest="0xad499113950f3410a60c6fe9fe40b4d1d98cf055eeafeb2b1736a5a38c5fea1e";
const deadline=BigInt(Date.parse("2026-11-26T19:50:06Z")/1000);
const zero="0x"+"0".repeat(64),zeroAddress="0x"+"0".repeat(40);
const source=JSON.parse(readFileSync(repository+"/docs/evidence/mobile-signing/protocol-mainnet.json"));
const pins=[source.constructors.find(r=>r.id==="directory"),source.bootstrapChildren.find(r=>r.address.toLowerCase()===factory.toLowerCase())];
assert.equal(pins.length,2);assert.ok(pins.every(Boolean));
const abi=parseAbi(["function pending() view returns(bytes32,uint48,uint48)","function nonce() view returns(uint64)",
 "function signerSetEpoch() view returns(uint64)","function suspended() view returns(bool)","function latestVersion() view returns(uint32)",
 "function factories(uint32) view returns(address,bytes32)","function currentFactory() view returns((address factory,bytes32 runtimeHash))",
 "function engineVersion() view returns(uint32)", "function signerA() view returns(address)", "function signerB() view returns(address)", "function signerC() view returns(address)", "function publicationDelay() view returns(uint48)", "function executionWindow() view returns(uint48)", "event ActionScheduled(bytes32 indexed digest,uint64 indexed nonce,uint48 executableAt,uint48 expiresAt)"]);
const getters=[["pending",[]],["nonce",[]],["signerSetEpoch",[]],["suspended",[]],["latestVersion",[]],["factories",[1]],["currentFactory",[]],["signerA",[]],["signerB",[]],["signerC",[]],["publicationDelay",[]],["executionWindow",[]]];
const allowedCalls=new Set(getters.map(([fn,args])=>directory.toLowerCase()+":"+encodeFunctionData({abi,functionName:fn,args})));
allowedCalls.add(factory.toLowerCase()+":"+encodeFunctionData({abi,functionName:"engineVersion"}));
const normalize=x=>typeof x==="bigint"||typeof x==="number"?String(x):Array.isArray(x)?x.map(normalize):x&&typeof x==="object"?Object.fromEntries(Object.entries(x).map(([k,v])=>[k,normalize(v)])):typeof x==="string"&&x.startsWith("0x")?x.toLowerCase():x;
const sha=bytes=>createHash("sha256").update(bytes).digest("hex");
const report={schemaVersion:1,scope:"BOUNDED_READ_ONLY_DIRECTORY_FACTORY_PUBLICATION_GETTERS",startedAt:new Date().toISOString(),
 scheduleTransactionHash:scheduleHash,sourceCommit:execFileSync("git",["rev-parse","HEAD"],{cwd:repository,encoding:"utf8"}).trim(),directory,factory,expectedDigest:digest,
 deadlineUtc:"2026-11-26T19:50:06Z",deadlineUnix:String(deadline),providers:{},requests:[],status:"UNKNOWN",
 signing:false,broadcast:false,governanceExecution:false,stateChangingSimulation:false,estimateGas:false,
 permittedMethods:["eth_chainId","eth_getBlockByNumber","eth_getCode","eth_call","eth_getTransactionReceipt"],limitations:["L2 provider agreement does not establish Ethereum L1 finality.","This read never simulates execute/cancel, prepares transactions, signs or broadcasts."]};
const save=()=>writeFileSync("/tmp/task089-governance-read.json",JSON.stringify(report,null,2)+"\n");
let id=0;
async function rpc(name,method,params=[]){
 assert.ok(report.permittedMethods.includes(method));
 if(method==="eth_call"){const [call,tag]=params;assert.deepEqual(Object.keys(call).sort(),["data","to"]);assert.ok(allowedCalls.has(call.to.toLowerCase()+":"+call.data));assert.match(tag,/^0x[0-9a-f]+$/);}
 if(method==="eth_getTransactionReceipt")assert.deepEqual(params,[scheduleHash]);
 if(method==="eth_getCode")assert.ok([directory.toLowerCase(),factory.toLowerCase()].includes(params[0].toLowerCase()));
 assert.ok(report.requests.length<48);
 const request={jsonrpc:"2.0",id:++id,method,params};
 const row={provider:name,requestedAt:new Date().toISOString(),request};report.requests.push(row);save();
 try{
  const response=await fetch(urls[name],{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(request),credentials:"omit",redirect:"error",signal:AbortSignal.timeout(10000)});
  row.httpStatus=response.status;const reader=response.body.getReader(),parts=[];let size=0;
  try{for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;assert.ok(size<=256*1024);parts.push(part.value);}}finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
  const bytes=Buffer.concat(parts.map(p=>Buffer.from(p)));row.responseSha256=sha(bytes);row.rawUtf8=bytes.toString("utf8");
  assert.equal(response.status,200,"PROVIDER_HTTP_"+response.status);const json=JSON.parse(row.rawUtf8);assert.equal(json.id,request.id);assert.equal(json.jsonrpc,"2.0");
  if(json.error){row.rpcError=json.error;throw Error("PROVIDER_RPC_"+json.error.code);}assert.ok("result" in json);row.status="OBSERVED";return json.result;
 }catch(error){row.status="UNAVAILABLE";row.error=String(error.message).slice(0,200);throw error;}finally{row.finishedAt=new Date().toISOString();save();if(name==="pocket")await delay(250);}
}
async function getter(name,to,fn,args,tag){return normalize(decodeFunctionResult({abi,functionName:fn,data:await rpc(name,"eth_call",[{to,data:encodeFunctionData({abi,functionName:fn,args})},tag])}));}
try{
 const heads={};
 for(const name of ["official","pocket"]){assert.equal(BigInt(await rpc(name,"eth_chainId")),4663n);heads[name]=await rpc(name,"eth_getBlockByNumber",["latest",false]);}
 const height=BigInt(heads.official.number)<BigInt(heads.pocket.number)?BigInt(heads.official.number):BigInt(heads.pocket.number),tag="0x"+height.toString(16);
 const anchors={};
 for(const name of ["official","pocket"]){const b=await rpc(name,"eth_getBlockByNumber",[tag,false]);assert.equal(BigInt(b.number),height);anchors[name]={number:String(height),hash:b.hash.toLowerCase(),timestamp:String(BigInt(b.timestamp))};}
 assert.deepEqual(anchors.official,anchors.pocket,"PROVIDER_CANONICAL_BLOCK_DISAGREEMENT");
 report.anchor={...anchors.official,timestampUtc:new Date(Number(BigInt(anchors.official.timestamp))*1000).toISOString()};
 assert.ok(Math.abs(Date.now()-Number(BigInt(report.anchor.timestamp))*1000)<=180000,"ANCHOR_NOT_FRESH");
 for(const name of ["official","pocket"]){
  const point={anchor:report.anchor,runtimePins:[],getters:{},canonicalRechecked:false};report.providers[name]=point;save();
  const receipt=await rpc(name,"eth_getTransactionReceipt",[scheduleHash]);
  assert.ok(receipt,"SCHEDULE_RECEIPT_UNAVAILABLE"); assert.equal(receipt.transactionHash.toLowerCase(),scheduleHash); assert.equal(BigInt(receipt.status),1n); assert.equal(receipt.to.toLowerCase(),directory.toLowerCase());
  assert.equal(String(BigInt(receipt.blockNumber)),scheduled.receiptBlock); assert.equal(receipt.blockHash.toLowerCase(),scheduled.blockHash);
  const scheduleBlock=await rpc(name,"eth_getBlockByNumber",[receipt.blockNumber,false]); assert.equal(scheduleBlock.hash.toLowerCase(),receipt.blockHash.toLowerCase());
  const events=receipt.logs.filter(log=>log.address.toLowerCase()===directory.toLowerCase()).flatMap(log=>{try{return [decodeEventLog({abi,eventName:"ActionScheduled",data:log.data,topics:log.topics,strict:true})]}catch{return []}});
  assert.equal(events.length,1); const event=normalize(events[0].args); assert.equal(event.digest,digest); assert.equal(event.nonce,"0"); assert.equal(event.executableAt,String(BigInt(scheduleBlock.timestamp)+172800n)); assert.equal(event.expiresAt,String(deadline));
  point.scheduleReceipt={transactionHash:scheduleHash,blockNumber:String(BigInt(receipt.blockNumber)),blockHash:receipt.blockHash.toLowerCase(),event};
  for(const pin of pins){const code=await rpc(name,"eth_getCode",[pin.address,tag]);assert.ok(code!=="0x");const hash=keccak256(code);point.runtimePins.push({address:pin.address,expectedHash:pin.runtimeHash,observedHash:hash,matches:hash.toLowerCase()===pin.runtimeHash.toLowerCase()});assert.equal(hash.toLowerCase(),pin.runtimeHash.toLowerCase(),"RUNTIME_DRIFT");}
  for(const [fn,args]of getters)point.getters[fn]=await getter(name,directory,fn,args,tag);
  point.getters.factoryEngineVersion=await getter(name,factory,"engineVersion",[],tag);
  const b=await rpc(name,"eth_getBlockByNumber",[tag,false]);assert.equal(b.hash.toLowerCase(),report.anchor.hash);assert.equal(String(BigInt(b.timestamp)),report.anchor.timestamp);point.canonicalRechecked=true;save();
 }
 assert.deepEqual(report.providers.official,report.providers.pocket,"PROVIDER_STATE_DISAGREEMENT");
 const state=report.providers.official.getters;report.state=state;const [pendingDigest,executableAt,expiresAt]=state.pending;
 const now=BigInt(report.anchor.timestamp);report.remainingToOwnerDeadlineSeconds=String(deadline-now);
 report.deadlineInclusive=true;
 assert.equal(state.publicationDelay,"172800"); assert.equal(state.executionWindow,"604800");
 assert.deepEqual([state.signerA,state.signerB,state.signerC],scheduled.currentDirectory[0].state ? ["signerA","signerB","signerC"].map(k=>scheduled.currentDirectory[0].state[k].toLowerCase()) : []);
 report.scheduleCanonicalAtObservation=true;
 report.publicationEffect={latestVersion:"1",factories1:factory.toLowerCase(),pendingCleared:true,actionNonceAfter:"1",createsToken:false,websiteFlagsEnforceOnChain:false,assetMovement:false,precondition:"exact pending digest, nonce/epoch, inclusive notice, factory runtime and engineVersion; no new signature required by execute"};
 if(pendingDigest===digest){
  report.pendingWindow={executableAt,expiresAt,deadlineMatches:BigInt(expiresAt)===deadline,remainingSeconds:String(BigInt(expiresAt)-now)};
  if(now>BigInt(expiresAt)){report.status="EXPIRED_PENDING_NOT_CLEARED";report.permissionlessPublicationRisk=false;}
  else{report.status=now<BigInt(executableAt)?"PENDING_NOTICE":"PENDING_TIME_ELIGIBLE";report.permissionlessPublicationRisk=now>=BigInt(executableAt)&&state.nonce==="0"&&state.signerSetEpoch==="1"&&state.latestVersion==="0"&&state.factories[0]===zeroAddress&&state.factoryEngineVersion==="1";}
 }else if(state.factories[0]===factory.toLowerCase()&&state.factories[1]===pins[1].runtimeHash.toLowerCase()){
  report.status="FACTORY_PUBLICATION_MAPPING_OBSERVED";report.operationExecutionIdentity="Cannot attribute exact scheduled digest from current getters alone";report.permissionlessPublicationRisk=false;
 }else if(pendingDigest===zero){report.status="PENDING_CLEARED_CAUSE_UNVERIFIED";report.operationExecutionIdentity="Getters alone do not distinguish cancellation, expiry clearing or signer rotation";report.permissionlessPublicationRisk="UNKNOWN";}
 else{report.status="DIFFERENT_PENDING_DIGEST";report.permissionlessPublicationRisk="UNKNOWN";}
 report.twoProvidersAgree=true;report.canonicalAnchorRechecked=true;
 assert.ok(Date.now()-Number(now)*1000<=180000,"CAPTURE_STALE_AT_COMPLETION");
}catch(error){report.failureCategory=String(error.message).slice(0,200);report.status="UNKNOWN";}
report.finishedAt=new Date().toISOString();report.producerSha256=sha(readFileSync("/tmp/task089-governance-read.mjs"));save();
console.log(JSON.stringify({status:report.status,anchor:report.anchor,state:report.state,pendingWindow:report.pendingWindow,remainingToOwnerDeadlineSeconds:report.remainingToOwnerDeadlineSeconds,permissionlessPublicationRisk:report.permissionlessPublicationRisk,requests:report.requests.length,failureCategory:report.failureCategory,output:"/tmp/task089-governance-read.json"},null,2));
