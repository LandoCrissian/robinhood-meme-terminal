import {createRequire} from 'node:module';
import {mkdirSync,writeFileSync} from 'node:fs';
import {runSeaportAcquisitionFixture} from 'file:///C:/Users/RMT/Documents/Codex/2026-11-11/rmt-task086/scripts/seaport-acquisition/fixture-run.mjs';
import {testTask086CollectionAcceptance} from 'file:///C:/Users/RMT/Documents/Codex/2026-11-11/rmt-task086/scripts/seaport-acquisition/task086-collection-acceptance.mjs';
const require=createRequire('file:///C:/Users/RMT/Documents/Codex/2026-11-11/rmt-task086/apps/indexer/package.json'),{createPublicClient,http}=require('viem');
const output='C:/Users/RMT/AppData/Local/Temp/rmt-task086-acceptance-local4';
mkdirSync(output,{recursive:true});
try{
 const result=await runSeaportAcquisitionFixture({anvil:'C:/Users/RMT/.codex/tools/foundry-v1.7.1/anvil.exe',solc:'C:/Users/RMT/Documents/Codex/2026-11-11/rmt-task083-evidence/solc.exe',lib:'C:/Users/RMT/Documents/Codex/2026-11-11/rmt-task083/packages/contracts/lib',forkRobinhood:true,output:output+'/chain',callback:async fixture=>{
  const witness=createPublicClient({transport:http(fixture.url,{retryCount:0,timeout:8000}),cacheTime:0});
  const report=await testTask086CollectionAcceptance({fixture,rpc:witness,out:output});
  console.log(JSON.stringify({task086:report.status,cases:report.cases.map(x=>({name:x.name,reason:x.proof.reason??null,status:x.receipt.status})),realCollection:{status:report.realCollection.status,direct:report.realCollection.directTransferFrom?.selector,policy:report.realCollection.validatorCall?.selector,simulation:report.realCollection.validatorSimulation?.decoded}}));
  return report;
 }});
 console.log(JSON.stringify({status:result.status,output,production:false}));
}catch(error){writeFileSync(output+'/standalone-failure.txt',String(error?.stack??error));throw error;}

